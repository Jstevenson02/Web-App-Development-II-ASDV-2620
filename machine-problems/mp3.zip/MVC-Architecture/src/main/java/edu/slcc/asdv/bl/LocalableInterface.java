/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.slcc.asdv.bl;

/**
 *
 * @author jacob
 */
public interface LocalableInterface {
    void englishLocale();
    void greekLocale();
    void germanLocale();
    void frenchLocale();
    void spanishLocale();
    void arabicLocale();
    void russianLocale();
    void chineseLocale();
}
